using UnityEngine;
using System.Collections;

[ExecuteInEditMode]
public class ProFlareOnPreRenderUpdater : MonoBehaviour {
	
	public ProFlareBatch batch;
	
	void Start(){
		if(!batch)
			this.enabled = false;
	}
	
	void OnPreRender () {
		if(batch)
			batch.UpdateFlares();
	}
	
	void LateUpdate(){
		if(!Application.isPlaying)
			if(batch)
				batch.UpdateFlares();
	}
}
