/// ProFlares - v1.05 - Copyright 2013-2014 All rights reserved - ProFlares.com

/// <summary>
/// ProFlaresOculusHelper.cs
/// Helper class that contains a number of functions that other Editor Scripts use.
/// </summary>

using UnityEngine;
using UnityEditor;
using System.Collections;

public class ProFlaresOculusHelper : MonoBehaviour {
	const int menuPos = 10000;
 	
	static int FlaresLeftLayer = 8;
	static int FlaresRightLayer = 9;
	
	[MenuItem ("Window/ProFlares/Create VR Setup On Selected OVR Controller",false,menuPos+30)]
	static void CreateFlareBatch () {
		
		OVRCameraController _OVRCameraController = null;
		GameObject OVR_GO = null;
		
		if(Selection.activeGameObject){
            
			_OVRCameraController = Selection.activeGameObject.GetComponent<OVRCameraController>();
			
			if(_OVRCameraController == null){
				Debug.LogError("ProFlares - Please Select Your OVRCameraController");
				return;
			}else{
				OVR_GO = Selection.activeGameObject;
			}
		}else{
			Debug.LogError("ProFlares - Nothing Selected");
			return;
		}
		
		Camera[] cameras = OVR_GO.GetComponentsInChildren<Camera>();
		
		Transform CameraLeft = null;
 		
		Transform CameraRight = null;
		
		for (int i = 0; i < cameras.Length; i++)
		{
			if(cameras[i].name == "CameraLeft")
				CameraLeft = cameras[i].transform;
			
		 	if(cameras[i].name == "CameraRight")
		 		CameraRight = cameras[i].transform;
		}
		
		GameObject batchGOLeft = new GameObject("ProFlareBatch_VR");
		
		batchGOLeft.layer = ProFlaresOculusHelper.FlaresLeftLayer;
		 
		batchGOLeft.transform.parent = CameraLeft;
		
		batchGOLeft.transform.localPosition = Vector3.zero;

		batchGOLeft.transform.localRotation = Quaternion.identity;
		
		batchGOLeft.transform.localScale = Vector3.one;
		
		ProFlareBatch batchLeft = batchGOLeft.AddComponent<ProFlareBatch>();
		
		batchLeft.FlareCamera = CameraLeft.camera;
		
		batchLeft.FlareCameraTrans = CameraLeft;
		 
		batchLeft.GameCamera = CameraLeft.camera;
		
		int layerMaskLeft = CameraLeft.camera.cullingMask;
		
		layerMaskLeft -= 1 << ProFlaresOculusHelper.FlaresRightLayer;
		
		CameraLeft.camera.cullingMask = layerMaskLeft;
			 
		batchLeft.mode = ProFlareBatch.Mode.VR;
		
		batchLeft.VR_Mode = true;
		
		batchLeft.zPos = 1;
		
		
		GameObject batchGORight = new GameObject("ProFlareBatch_VR");
		
		batchGORight.layer = ProFlaresOculusHelper.FlaresRightLayer;
		 
		batchGORight.transform.parent = CameraRight;
		
		batchGORight.transform.localPosition = Vector3.zero;

		batchGORight.transform.localRotation = Quaternion.identity;
		
		batchGORight.transform.localScale = Vector3.one;
		
		ProFlareBatch batchRight = batchGORight.AddComponent<ProFlareBatch>();
		
		batchRight.FlareCamera = CameraLeft.camera;
		
		batchRight.FlareCameraTrans = CameraLeft;
		 
		batchRight.GameCamera = CameraLeft.camera;
		
		int layerMaskRight = CameraRight.camera.cullingMask;
		
		layerMaskRight -= 1 << ProFlaresOculusHelper.FlaresLeftLayer;
		
		CameraRight.camera.cullingMask = layerMaskRight;
			 
		batchRight.mode = ProFlareBatch.Mode.VR;
		
		batchRight.VR_Mode = true;
		
		batchRight.zPos = 1;
		
		ProFlareOnPreRenderUpdater _ProFlareOnPreRenderUpdaterLeft = CameraLeft.gameObject.AddComponent<ProFlareOnPreRenderUpdater>();
		
		_ProFlareOnPreRenderUpdaterLeft.batch = batchLeft;
		
		ProFlareOnPreRenderUpdater _ProFlareOnPreRenderUpdaterRight = CameraRight.gameObject.AddComponent<ProFlareOnPreRenderUpdater>();
		
		_ProFlareOnPreRenderUpdaterRight.batch = batchRight;
		
		//Selection.activeGameObject = batchGORight;
		
	}
}
